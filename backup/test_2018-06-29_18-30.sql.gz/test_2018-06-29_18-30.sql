#SKD101|test|1|2018.06.29 18:30:32|14|14

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `user` VALUES
(1, 'Em', 'mail@mail.ru', '123456'),
(2, 'zoro', 'zoro@zoro.com', '987654321'),
(3, 'zoro', 'zoro@zoro.com', '987654321'),
(4, 'zohan', 'zohan@zuw.fu', '987654321'),
(5, 'O\'Konor', 'konor@mail.ru', '11112222'),
(6, 'ivan', 'ivan@mail.ru', '123'),
(7, 'ivan', 'ivan@mail.ru', '123'),
(8, 'ivan', 'ivan@mail.ru', '123'),
(9, 'ivan', 'ivan@mail.ru', '123'),
(10, 'ivan', 'ivan@mail.ru', '123'),
(11, 'ivan', 'ivan@mail.ru', '123'),
(12, 'Bob', 'bob@boby.com', ''),
(13, 'New Bob', 'bob@boby.com', '');

